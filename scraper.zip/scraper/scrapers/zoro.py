from playwright.async_api import async_playwright
import asyncio, re
from typing import Optional

ZORO_BASE = "https://hianime.to"
# Zoro.to is now hianime.to

async def scrape_zoro(
  anime_title: str,
  episode_number: int
) -> Optional[dict]:
  """
  Scrapes from HiAnime (formerly Zoro.to).
  """
  
  async with async_playwright() as p:
    browser = await p.chromium.launch(
      headless=True,
      args=['--no-sandbox', '--disable-setuid-sandbox',
            '--disable-dev-shm-usage']
    )
    
    captured_m3u8 = []
    captured_vtt = []
    
    context = await browser.new_context(
      user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                 "AppleWebKit/537.36 (KHTML, like Gecko) "
                 "Chrome/120.0.0.0 Safari/537.36"
    )
    page = await context.new_page()
    
    async def handle_request(request):
      url = request.url
      if '.m3u8' in url:
        captured_m3u8.append(url)
      elif url.endswith('.vtt') or 'subtitle' in url.lower():
        captured_vtt.append(url)
    
    page.on('request', handle_request)
    
    try:
      # Search for the anime
      search_url = f"{ZORO_BASE}/search?keyword={anime_title.replace('-', '+')}"
      await page.goto(search_url, wait_until='networkidle', timeout=30000)
      
      # Click first result
      first_result = await page.query_selector(
        '.film-poster a, .flw-item a.film-poster'
      )
      if not first_result:
        return None
      
      show_href = await first_result.get_attribute('href')
      show_url = f"{ZORO_BASE}{show_href}"
      
      await page.goto(show_url, wait_until='networkidle', timeout=30000)
      await asyncio.sleep(1)
      
      # Find the episode link
      ep_link = await page.query_selector(
        f'a[data-number="{episode_number}"], '
        f'.ep-item[data-number="{episode_number}"]'
      )
      if not ep_link:
        # Try first episode as fallback
        ep_link = await page.query_selector('.ep-item')
      
      if ep_link:
        await ep_link.click()
        await asyncio.sleep(4)  # Wait for player to load
      
      # Some sites load player in iframe
      iframe = await page.query_selector('iframe#iframe-embed, iframe.embed-iframe')
      if iframe and not captured_m3u8:
        iframe_src = await iframe.get_attribute('src')
        if iframe_src:
          iframe_page = await context.new_page()
          iframe_page.on('request', handle_request)
          full_src = iframe_src if iframe_src.startswith('http') \
            else f"{ZORO_BASE}{iframe_src}"
          await iframe_page.goto(full_src, wait_until='networkidle', timeout=20000)
          await asyncio.sleep(4)
          await iframe_page.close()
    
    except Exception as e:
      print(f"Zoro scrape error: {e}")
    finally:
      await browser.close()
    
    if captured_m3u8:
      master = next(
        (u for u in captured_m3u8 if 'master' in u.lower()),
        captured_m3u8[0]
      )
      
      # Parse VTT subtitles captured
      subtitles = []
      for vtt_url in captured_vtt:
        lang = "en"
        label = "English"
        if "arabic" in vtt_url.lower() or ".ar." in vtt_url:
          lang, label = "ar", "Arabic"
        elif "spanish" in vtt_url.lower() or ".es." in vtt_url:
          lang, label = "es", "Spanish"
        elif "french" in vtt_url.lower() or ".fr." in vtt_url:
          lang, label = "fr", "French"
        subtitles.append({"lang": lang, "url": vtt_url, "label": label})
      
      return {
        "url": master,
        "type": "hls",
        "quality": "auto",
        "subtitles": subtitles,
        "source": "zoro"
      }
    
    return None

async def check_source_zoro(anime_title: str) -> dict:
  import httpx
  search_url = f"{ZORO_BASE}/search?keyword={anime_title}"
  async with httpx.AsyncClient(
    headers={"User-Agent": "Mozilla/5.0"},
    follow_redirects=True
  ) as client:
    try:
      resp = await client.get(search_url, timeout=10)
      has_results = '\"totalItems\"' in resp.text or \
                    'film-poster' in resp.text
      return {"available": has_results, "url": search_url}
    except:
      return {"available": False, "url": search_url}
