from playwright.async_api import async_playwright
import asyncio, re
from typing import Optional

GOGOANIME_BASE = "https://anitaku.pe"  
# GogoAnime's current active domain (changes often — 
# update this if it stops working)

async def scrape_gogoanime(
  anime_title: str, 
  episode_number: int
) -> Optional[dict]:
  """
  Scrapes a streaming URL from GogoAnime for a given 
  anime title and episode number.
  """
  
  async with async_playwright() as p:
    browser = await p.chromium.launch(
      headless=True,
      args=['--no-sandbox', '--disable-setuid-sandbox',
            '--disable-dev-shm-usage']
    )
    
    captured_m3u8 = []
    captured_mp4 = []
    
    context = await browser.new_context(
      user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                 "AppleWebKit/537.36 (KHTML, like Gecko) "
                 "Chrome/120.0.0.0 Safari/537.36",
      viewport={"width": 1920, "height": 1080}
    )
    page = await context.new_page()
    
    # Intercept requests to capture stream URLs
    async def handle_request(request):
      url = request.url
      if '.m3u8' in url and 'master' in url.lower():
        captured_m3u8.append(url)
      elif '.m3u8' in url:
        captured_m3u8.append(url)
      elif url.endswith('.mp4'):
        captured_mp4.append(url)
    
    page.on('request', handle_request)
    
    episode_url = f"{GOGOANIME_BASE}/{anime_title}-episode-{episode_number}"
    
    try:
      await page.goto(episode_url, 
        wait_until='networkidle',
        timeout=30000)
      
      # Wait a moment for any player to initialize
      await asyncio.sleep(2)
      
      # Try clicking play button if it exists
      try:
        play_btn = await page.query_selector('.play-btn, #play-btn, .vjs-play-control')
        if play_btn:
          await play_btn.click()
          await asyncio.sleep(3)
      except:
        pass
      
      # Check for iframe with embedded player
      if not captured_m3u8:
        iframe = await page.query_selector('iframe#player_iframe, iframe.play-video, div.play-video iframe')
        if iframe:
          iframe_src = await iframe.get_attribute('src')
          if iframe_src:
            iframe_page = await context.new_page()
            iframe_page.on('request', handle_request)
            await iframe_page.goto(iframe_src, 
              wait_until='networkidle',
              timeout=20000)
            await asyncio.sleep(3)
            await iframe_page.close()
    
    except Exception as e:
      print(f"GogoAnime scrape error: {e}")
    finally:
      await browser.close()
    
    # Return best quality stream found
    if captured_m3u8:
      # Prefer master playlist (contains multiple qualities)
      master = next(
        (u for u in captured_m3u8 if 'master' in u.lower()), 
        captured_m3u8[0]
      )
      return {
        "url": master,
        "type": "hls",
        "quality": "auto",
        "subtitles": [],
        "source": "gogoanime"
      }
    
    if captured_mp4:
      return {
        "url": captured_mp4[0],
        "type": "mp4", 
        "quality": "720p",
        "subtitles": [],
        "source": "gogoanime"
      }
    
    return None

async def check_source_gogoanime(anime_title: str) -> dict:
  """Quick check if anime exists on GogoAnime without full scrape"""
  url = f"{GOGOANIME_BASE}/{anime_title}-episode-1"
  import httpx
  async with httpx.AsyncClient(
    headers={"User-Agent": "Mozilla/5.0"}, 
    follow_redirects=True
  ) as client:
    try:
      resp = await client.get(url, timeout=10)
      return {
        "available": resp.status_code == 200,
        "url": url
      }
    except:
      return {"available": False, "url": url}
