from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import asyncio, os, redis, json, hashlib, time
from dotenv import load_dotenv
from scrapers.gogoanime import scrape_gogoanime, check_source_gogoanime
from scrapers.zoro import scrape_zoro, check_source_zoro

load_dotenv()
app = FastAPI(title="SAKURA Scraper Service", version="1.0.0")

app.add_middleware(
  CORSMiddleware,
  allow_origins=os.getenv("ALLOWED_ORIGINS", "").split(","),
  allow_methods=["GET", "POST"],
  allow_headers=["*"],
)

# Redis connection
r = redis.from_url(os.getenv("REDIS_URL", "redis://localhost:6379"))

# Simple API key auth
def verify_key(x_api_key: str = Header(...)):
  if x_api_key != os.getenv("SECRET_KEY"):
    raise HTTPException(status_code=403, detail="Invalid API key")

class ExtractRequest(BaseModel):
  anime_title: str        # e.g. "attack-on-titan"
  episode_number: int     # e.g. 1
  source: str = "gogoanime"  # "gogoanime" | "zoro"

class StreamResponse(BaseModel):
  url: str
  type: str               # "hls" | "mp4"
  quality: str            # "1080p" | "720p" | "auto"
  subtitles: list[dict]   # [{lang, url, label}]
  source: str
  cached: bool

@app.get("/health")
async def health():
  try:
    redis_ok = r.ping()
  except:
    redis_ok = False
    
  return {
    "status": "ok",
    "service": "SAKURA Scraper",
    "scrapers": ["gogoanime", "zoro"],
    "redis": redis_ok
  }

@app.post("/extract", dependencies=[Depends(verify_key)])
async def extract_stream(req: ExtractRequest):
  # Cache key
  cache_key = f"stream:{req.source}:{req.anime_title}:{req.episode_number}"
  cached = r.get(cache_key)
  if cached:
    data = json.loads(cached)
    data["cached"] = True
    return StreamResponse(**data)
  
  # Route to correct scraper
  if req.source == "gogoanime":
    result = await scrape_gogoanime(req.anime_title, req.episode_number)
  elif req.source == "zoro":
    result = await scrape_zoro(req.anime_title, req.episode_number)
  else:
    raise HTTPException(status_code=400, detail="Unknown source")
  
  if not result:
    raise HTTPException(
      status_code=404, 
      detail=f"No stream found for {req.anime_title} ep {req.episode_number}"
    )
  
  # Cache for 2 hours (stream URLs expire)
  r.setex(cache_key, 7200, json.dumps(result))
  result["cached"] = False
  return StreamResponse(**result)

@app.get("/sources/{anime_title}", dependencies=[Depends(verify_key)])
async def get_available_sources(anime_title: str):
  """Check which sources have a specific anime"""
  results = await asyncio.gather(
    check_source_gogoanime(anime_title),
    check_source_zoro(anime_title),
    return_exceptions=True
  )
  return {
    "gogoanime": results[0] if not isinstance(results[0], Exception) else None,
    "zoro": results[1] if not isinstance(results[1], Exception) else None
  }
