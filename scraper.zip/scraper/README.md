# SAKURA Scraper Service

## Local Development
pip install -r requirements.txt
playwright install chromium
uvicorn main:app --reload --port 8000

## Deploy to Railway
1. Create new project on railway.app
2. Connect this /scraper folder as the service
3. Set env vars: REDIS_URL, SECRET_KEY, ALLOWED_ORIGINS
4. Railway auto-detects Dockerfile

## Test the scraper
curl -X POST http://localhost:8000/extract \
  -H "Content-Type: application/json" \
  -H "x-api-key: your-secret-key" \
  -d '{"anime_title":"attack-on-titan","episode_number":1,"source":"gogoanime"}'
